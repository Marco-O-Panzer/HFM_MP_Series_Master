Installation:
1. Copy the folder "launcher" into your Victoria II main directory, NOT the mod folder.
2. Replace the files in the destination.
3. Launch Victoria II.

A copy of the vanilla launcher is included to revert back without verifying your files.